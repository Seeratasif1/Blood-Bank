# Blood-Bank
Discover our Blood Bank website, bridging donors to those in need seamlessly. With HTML, CSS, PHP, and React, find donors by location, blood type, and availability. Register easily, get real-time updates, and join the life-saving mission now!
